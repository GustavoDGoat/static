import React, { useState } from 'react'

const CookieBanner = () => {
  const [visible, setVisible] = useState(true)

  if (!visible) return null

  return (
    <div className="fixed bottom-0 left-0 w-full bg-gray-900 text-white px-4 py-3 flex flex-col md:flex-row items-center justify-between z-50">
      <p className="text-sm mb-2 md:mb-0">
        We use cookies to improve your experience. By using DataMint, you agree to our Privacy Policy.
      </p>
      <div className="flex space-x-2">
        <button
          onClick={() => setVisible(false)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-1 rounded-md text-sm"
        >
          Accept
        </button>
        <button
          onClick={() => setVisible(false)}
          className="bg-gray-700 hover:bg-gray-600 text-white px-4 py-1 rounded-md text-sm"
        >
          Decline
        </button>
      </div>
    </div>
  )
}

export default CookieBanner

import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { MenuIcon, XIcon } from 'lucide-react'
const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  return (
    <header className="py-6 px-4 md:px-8 lg:px-12">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="flex items-center space-x-2">
          <img
            src="https://uploadthingy.s3.us-west-1.amazonaws.com/mvgGTk4dn2WuqzYX4iEmVZ/file_00000000906862439d31c9234df1bce0.png"
            alt="DataMint Logo"
            className="h-10 w-auto"
          />
          <span className="text-2xl font-bold text-indigo-900">DataMint</span>
        </Link>
        {/* Mobile menu button */}
        <button
          className="md:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? (
            <XIcon className="h-6 w-6 text-indigo-900" />
          ) : (
            <MenuIcon className="h-6 w-6 text-indigo-900" />
          )}
        </button>
        {/* Desktop navigation */}
        <nav className="hidden md:flex space-x-8 items-center">
          <Link
            to="/"
            className="text-indigo-900 hover:text-indigo-700 font-medium"
          >
            Home
          </Link>
          <Link
            to="/partnerships"
            className="text-indigo-900 hover:text-indigo-700 font-medium"
          >
            Partner with DataMint
          </Link>
          <Link
            to="/"
            className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-md font-medium"
          >
            Join Waitlist
          </Link>
        </nav>
      </div>
      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden mt-4 bg-white rounded-lg shadow-lg p-4">
          <nav className="flex flex-col space-y-4">
            <Link
              to="/"
              className="text-indigo-900 hover:text-indigo-700 font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              to="/partnerships"
              className="text-indigo-900 hover:text-indigo-700 font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              Partner with DataMint
            </Link>
            <Link
              to="/"
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-md font-medium text-center"
              onClick={() => setIsMenuOpen(false)}
            >
              Join Waitlist
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}
export default Header

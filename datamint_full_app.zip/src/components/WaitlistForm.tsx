import React, { useState } from 'react'

const WaitlistForm = () => {
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    await fetch("https://formspree.io/f/xeolbedb", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    })
    setSubmitted(true)
  }

  if (submitted) {
    return <p className="text-green-600 font-medium">Thanks for joining the waitlist!</p>
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row items-center gap-2">
      <input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="Enter your email"
        required
        className="w-full sm:w-auto px-4 py-2 border rounded-md focus:ring focus:ring-indigo-400"
      />
      <button
        type="submit"
        className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-md"
      >
        Join Waitlist
      </button>
    </form>
  )
}

export default WaitlistForm

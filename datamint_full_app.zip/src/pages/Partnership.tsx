import React from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'

const Partnership = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold mb-6">Partner with DataMint</h1>
        <p className="mb-4">We’re excited to collaborate with like-minded companies and individuals who believe in giving users control over their data.</p>
        <p className="mb-4">If you’d like to explore partnership opportunities, please reach out to us at datamintapp@gmail.com.</p>
      </main>
      <Footer />
    </div>
  )
}

export default Partnership

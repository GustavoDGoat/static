import React from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'
import WaitlistForm from '../components/WaitlistForm'

const HomePage = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow">
        <section className="text-center py-20 bg-gray-50">
          <h1 className="text-4xl md:text-6xl font-bold text-indigo-900 mb-6">
            Own Your Data. Earn. Take Back Control.
          </h1>
          <p className="text-lg md:text-xl text-gray-700 max-w-2xl mx-auto mb-8">
            Every day, tech giants profit from your clicks, searches, and purchases. Your data fuels the digital economy — but you, the real owner, get nothing in return.
          </p>
          <WaitlistForm />
        </section>
      </main>
      <Footer />
    </div>
  )
}

export default HomePage

import React from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'

const TermsOfUse = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold mb-6">Terms of Use</h1>
        <p className="mb-4">By accessing and using DataMint, you agree to these terms and conditions.</p>
        <p className="mb-4">You are responsible for the accuracy of the information you provide.</p>
        <p className="mb-4">We reserve the right to update these terms at any time.</p>
      </main>
      <Footer />
    </div>
  )
}

export default TermsOfUse

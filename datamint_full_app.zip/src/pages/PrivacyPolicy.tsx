import React from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'

const PrivacyPolicy = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold mb-6">Privacy Policy</h1>
        <p className="mb-4">Your privacy is important to us. This policy explains how DataMint collects, uses, and protects your information.</p>
        <p className="mb-4">We only collect data you choose to share with us, and you can opt out at any time.</p>
        <p className="mb-4">We never sell your personal information to third parties.</p>
      </main>
      <Footer />
    </div>
  )
}

export default PrivacyPolicy
